using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.EntityFrameworkCore;
using slash_get_access.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using slash_get_access.Entities;
using Microsoft.AspNetCore.Http;

namespace slash_get_access
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseMySQL(
                    Configuration.GetConnectionString("ApplicationDbContext")));
            services.AddDefaultIdentity<IdentityUser>(options =>
            {
                options.SignIn.RequireConfirmedAccount = false;
                options.Password.RequiredLength = 3;
                options.Password.RequireLowercase = false;
                options.Password.RequireUppercase = false;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequireDigit = false;

            })
                .AddRoles<IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>();

            services.AddRazorPages(options =>
            {
                options.Conventions.AuthorizeFolder("/");
            }).AddRazorRuntimeCompilation();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IServiceProvider serviceProvider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            List<string> restrictedURLs = Configuration.GetSection("RestrictedURLs").Get<List<string>>();

            if(restrictedURLs != null)
            {
                if (restrictedURLs.Count != 0)
                {
                    app.UseMiddleware<SlashGetAccessMiddleware>(restrictedURLs);
                }
            }


            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();

                endpoints.MapGet("/Identity/Account/Register", context => Task.Factory.StartNew(() => context.Response.Redirect("/Identity/Account/Login", true, true)));
                endpoints.MapPost("/Identity/Account/Register", context => Task.Factory.StartNew(() => context.Response.Redirect("/Identity/Account/Login", true, true)));

            });

            ConfigureRoles(serviceProvider).Wait();
            ConfigureUsers(serviceProvider).Wait();
            InitializeBooks(serviceProvider);
        }

        private async Task ConfigureRoles(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            if (await roleManager.FindByNameAsync("Admin") == null)
            {
                
                string[] availableRoles = { "Admin", "User" };

                foreach (var role in availableRoles)
                {
                    if (!await roleManager.RoleExistsAsync(role))
                    {
                        await roleManager.CreateAsync(new IdentityRole(role));
                    }
                }
            }
        }

        private async Task ConfigureUsers(IServiceProvider serviceProvider)
        {
            var userManager = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();

            if (await userManager.FindByEmailAsync("admin@mail.com") == null)
            {

                var admin = new IdentityUser { UserName = "admin", Email = "admin@mail.com", EmailConfirmed = true };
                var adminResult = await userManager.CreateAsync(admin, "usr90-SJv0PHb0KMd3L7CuSTEr");

                if (adminResult.Succeeded)
                {
                    await userManager.AddToRoleAsync(admin, "Admin");
                }

                var user = new IdentityUser { UserName = "user", Email = "user@mail.com", EmailConfirmed = true };
                var userResult = await userManager.CreateAsync(user, "user");

                if (userResult.Succeeded)
                {
                    await userManager.AddToRoleAsync(user, "User");
                }
            }
        }

        public void InitializeBooks(IServiceProvider serviceProvider)
        {
            var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>());

            if (!context.Book.Any())
            {
                context.Book.AddRange(
                    new Book
                    (
                        "Life 3.0: Being Human in the Age of Artificial Intelligence",
                        "Max Tegmark"
                    ),
                    new Book
                    (
                        "Zero to One: Notes on Startups, or How to Build the Future",
                        "Peter Thiel, Blake Masters"

                    ),
                    new Book
                    (
                        "Sapiens: A Brief History of Humankind",
                        "Yuval Noah Harari"

                    ),
                    new Book
                    (
                        "Billions and Billions",
                        "Carl Sagan"
                    ),
                    new Book
                    (
                        "Can't Hurt Me: Master Your Mind and Defy the Odds",
                        "David Goggins"

                    ),
                    new Book
                    (
                        "1984",
                        "George Orwell"
                    ),
                    new Book
                    (
                        "The Hitchhiker's Guide to the Galaxy",
                        "Douglas Adams"

                    ),
                    new Book
                    (
                        "Contact: A Novel",
                        "Carl Sagan"

                    ),
                    new Book
                    (
                        "Cosmos",
                        "Carl Sagan"

                    )
                );

                context.SaveChanges();
            }

        }

    }
}
