using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using slash_get_access.Data;
using slash_get_access.Entities;

namespace slash_get_access.Pages.Books
{
    public class DetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public DetailsModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public Book Book { get; set; }
        public List<Book> OtherBooksByAuthor { get; set; }

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            try
            {
                Book = await _context.Book.FirstOrDefaultAsync(m => m.Id == id);

                if (Book.CreatedByAdmin)
                {
                    var query = $"select * from Book where Author='{Book.Author}' and Id != '{id}'";
                    OtherBooksByAuthor = await _context.Book.FromSqlRaw(query).ToListAsync();
                }

                if (Book == null)
                {
                    return NotFound();
                }

                return Page();

            }
            catch(MySqlException ex)
            {
                OtherBooksByAuthor = new List<Book>();
                ViewData["ErrorMessage"] = ex.Message;
                return Page();
            }
     
        }
    }
}
