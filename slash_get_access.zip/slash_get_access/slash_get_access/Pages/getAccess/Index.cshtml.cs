using System;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace slash_get_access.Pages.getAccess
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}