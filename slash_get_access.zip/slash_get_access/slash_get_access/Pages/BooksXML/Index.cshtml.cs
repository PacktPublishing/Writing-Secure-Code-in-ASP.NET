using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using slash_get_access.Data;
using slash_get_access.Entities;

namespace slash_get_access.Pages.BooksXML
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {

        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly ApplicationDbContext _context;

        public IndexModel(IWebHostEnvironment environment, ApplicationDbContext context)
        {
            _hostEnvironment = environment;
            _context = context;
        }

        [Required]
        [Display(Name = "File")]
        [BindProperty]
        public IFormFile FormFile { get; set; }

        public void OnGet()
        {

        }

        public async void OnPostAsync()
        {
            string fileContent;

            using (var streamReader = new StreamReader(FormFile.OpenReadStream()))
            {
                fileContent = streamReader.ReadToEnd();
            }

            var doc = new XmlDocument();

            using var stream = new MemoryStream(Encoding.Default.GetBytes(fileContent));
            var settings = new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Parse,
                MaxCharactersFromEntities = 0
            };

            using var reader = XmlReader.Create(stream, settings);

            doc.Load(reader);

            XmlNodeList books = doc.GetElementsByTagName("Book");
      
            for (int i = 0; i < books.Count; i++)
            {
                if (books[i].InnerText.Length > 0)
                {
                    var childNodes = books[i].ChildNodes;

                    if(childNodes[0].InnerText != null || childNodes[1].InnerText != null)
                    {
                        _context.Add(new Book(childNodes[0].InnerText, childNodes[1].InnerText, true));
                        await _context.SaveChangesAsync();
                    }
                }
            }

            TempData["UploadMessage"] = "Created books successfully!";

        }
    }
}