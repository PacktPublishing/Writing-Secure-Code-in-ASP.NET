using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using slash_get_access.Data;

namespace slash_get_access.Pages.Uploads
{

    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {

        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly ApplicationDbContext _context;

        public IndexModel(IWebHostEnvironment environment, ApplicationDbContext context)
        {
            _hostEnvironment = environment;
            _context = context;
        }


        [BindProperty(SupportsGet = true)]
        public string FileName { get; set; }

        public string FileContent { get; set; }

        public IList<string> UploadedFiles { get; set; }

        public void OnGet()
        {
            var dirPath = _hostEnvironment.ContentRootPath + "/wwwroot/resources";

            DirectoryInfo d = new DirectoryInfo(dirPath);

            FileInfo[] Files = d.GetFiles();
            List<string> fileNames = new List<string>();

            foreach (FileInfo file in Files)
            {
                fileNames.Add(file.Name);
            }

            if (!string.IsNullOrEmpty(FileName))
            {
                try
                {
                    var fileContents = System.IO.File.ReadAllText(dirPath + "/" + FileName);
                    FileContent = fileContents;
                }
                catch (Exception e)
                {
                    FileContent = "File not found!";
                }
    
            }

            UploadedFiles = fileNames;
        }

    }
}