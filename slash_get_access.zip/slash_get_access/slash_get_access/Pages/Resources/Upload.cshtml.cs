using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace slash_get_access.Pages.Resources
{
    [Authorize(Roles = "Admin")]
    public class UploadModel : PageModel
    {

        private readonly IWebHostEnvironment _hostEnvironment;

        [Required]
        [Display(Name = "File")]
        [BindProperty]
        public IFormFile FormFile { get; set; }

        public UploadModel(IWebHostEnvironment environment)
        {
            _hostEnvironment = environment;
        }

        public void OnGet()
        {

        }

        public async Task<PageResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            try
            {
                var fullFilePath = _hostEnvironment.ContentRootPath + "/wwwroot/resources/" + FormFile.FileName;
                using (var stream = System.IO.File.Create(fullFilePath))
                {
                    await FormFile.CopyToAsync(stream);
                }


                TempData["UploadMessage"] = "Uploaded file successfully!";
                return Page();
            }
            catch (Exception ex)
            {
                TempData["UploadMessage"] = ex.Message;
                return Page();
            }
           
        }
    }
}