### Run in Docker
NOTE: https is not enabled if you run in docker

```sh
// Start
docker-compose up

// Start Detach mode
docker-compose up -d

//Stop
docker-compose down

```

Exposed at http://localhost:5001


### Remove the containers and image
```sh
docker rm -f slash_get_access_db_1 && docker rm -f slash_get_access_app_1 && docker image rm -f slash_get_access
```
