﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace slash_get_access
{
    public class SlashGetAccessMiddleware
    {

        private readonly List<string> _restrictedURLs;
        private readonly RequestDelegate _next;

        public SlashGetAccessMiddleware(RequestDelegate next, List<string> restrictedURLs)
        {
            _restrictedURLs = restrictedURLs;
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {

            if (_restrictedURLs.Contains(context.Request.Path))
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                context.Response.Redirect($"/neinAccess?restricedURL={context.Request.Path}");
                return;
            }

            await _next.Invoke(context);
        }
    }
}
