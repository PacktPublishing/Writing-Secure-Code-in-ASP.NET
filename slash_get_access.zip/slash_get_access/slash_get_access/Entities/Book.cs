﻿using System;
namespace slash_get_access.Entities
{
    public class Book
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Author { get; set; }
        public bool CreatedByAdmin { get; set; } = false;

        public Book(string name, string author)
        {
            Id = Guid.NewGuid().ToString();
            Name = name;
            Author = author;
        }

        public Book()
        {
        }

        public Book(string id, string name, string author, bool createdByAdmin) : this(id, name)
        {
            Author = author;
            CreatedByAdmin = createdByAdmin;
        }

        public Book(string name, string author, bool createdByAdmin) : this(name, author)
        {
            CreatedByAdmin = createdByAdmin;
        }
    }
}
